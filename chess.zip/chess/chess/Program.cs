﻿using System;

class Program
{
    const int SIZE = 8;
    static int[,] board = new int[SIZE, SIZE];

    static readonly (int, int)[] KnightMoves = {
        (2, 1), (1, 2), (-1, 2), (-2, 1),
        (-2, -1), (-1, -2), (1, -2), (2, -1)
    };

    static void Main()
    {
        Console.Write("Row (0-7): ");
        int startRow = int.Parse(Console.ReadLine());

        Console.Write("Column (0-7): ");
        int startCol = int.Parse(Console.ReadLine());

        PlaceKentavr(startRow, startCol);

        while (true)
        {
            var next = GetNextPosition();
            if (next == null)
                break;

            PlaceKentavr(next.Value.Item1, next.Value.Item2);
        }

        Console.WriteLine("\nFinal Board:");
        PrintBoard();
    }

    static void PlaceKentavr(int row, int col)
    {
        board[row, col] = 1;
        MarkAttackedCells(row, col);
        Console.WriteLine($"\nPlaced Kentavr at ({row}, {col})");
        PrintBoard();
    }

    static void MarkAttackedCells(int row, int col)
    {
        for (int i = 0; i < SIZE; i++)
        {
            if (board[row, i] == 0) board[row, i] = -1;
            if (board[i, col] == 0) board[i, col] = -1;
        }

        foreach (var (dr, dc) in KnightMoves)
        {
            int newRow = row + dr;
            int newCol = col + dc;
            if (IsInside(newRow, newCol) && board[newRow, newCol] == 0)
                board[newRow, newCol] = -1;
        }
    }

    static (int, int)? GetNextPosition()
    {
        int maxFree = -1;
        (int, int)? best = null;
        int[,] scoreBoard = new int[SIZE, SIZE];

        for (int r = 0; r < SIZE; r++)
        {
            for (int c = 0; c < SIZE; c++)
            {
                if (board[r, c] != 0) continue;

                int score = CountFreeCellsAfterPlacement(r, c);
                scoreBoard[r, c] = score;

                if (score > maxFree)
                {
                    maxFree = score;
                    best = (r, c);
                }
            }
        }

        Console.WriteLine("\nHeuristic scores (remaining free cells if Kentavr placed):");
        for (int r = 0; r < SIZE; r++)
        {
            for (int c = 0; c < SIZE; c++)
            {
                if (board[r, c] != 0)
                {
                    Console.Write("XX ");
                }
                else
                {
                    if (scoreBoard[r, c] == maxFree)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.Write(scoreBoard[r, c].ToString("D2") + " ");
                        Console.ResetColor();
                    }
                    else
                    {
                        Console.Write(scoreBoard[r, c].ToString("D2") + " ");
                    }
                }
            }
            Console.WriteLine();
        }

        if (best != null)
        {
            Console.WriteLine($"\n--> Best cell to place next Kentavr: ({best.Value.Item1}, {best.Value.Item2}) with {maxFree} remaining free cells.");
        }

        return best;
    }

    static int CountFreeCellsAfterPlacement(int row, int col)
    {
        int[,] temp = (int[,])board.Clone();
        temp[row, col] = 1;

        for (int i = 0; i < SIZE; i++)
        {
            if (temp[row, i] == 0) temp[row, i] = -1;
            if (temp[i, col] == 0) temp[i, col] = -1;
        }

        foreach (var (dr, dc) in KnightMoves)
        {
            int newRow = row + dr;
            int newCol = col + dc;
            if (IsInside(newRow, newCol) && temp[newRow, newCol] == 0)
                temp[newRow, newCol] = -1;
        }

        int count = 0;
        foreach (var cell in temp)
            if (cell == 0) count++;

        return count;
    }

    static void PrintBoard()
    {
        Console.WriteLine();
        for (int r = 0; r < SIZE; r++)
        {
            for (int c = 0; c < SIZE; c++)
            {
                if (board[r, c] == 1)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write("K ");
                    Console.ResetColor();
                }
                else if (board[r, c] == -1)
                {
                    Console.Write("1 ");
                }
                else
                {
                    Console.Write("0 ");
                }
            }
            Console.WriteLine();
        }
    }
    static bool IsInside(int r, int c) => r >= 0 && r < SIZE && c >= 0 && c < SIZE;
}